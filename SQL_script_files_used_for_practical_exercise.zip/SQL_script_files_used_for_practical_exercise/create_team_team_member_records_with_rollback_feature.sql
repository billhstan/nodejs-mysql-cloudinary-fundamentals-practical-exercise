-- Tell the DB engine not to "automatically" commit any record changes (make the changes permanent)
-- until you "say so".
 SET autocommit = 0; 
START TRANSACTION;
INSERT INTO team(team_name, team_description)
      VALUES ('TEAM C','TEAM C DESCRIPTION' );
INSERT INTO team_member(first_name,last_name, member_email,is_leader, team_id) 
          VALUES ('FRED','HANS','fred_hans@email.com',
          true, 
          (SELECT team_id FROM team WHERE team_name='TEAM C') );
INSERT INTO team_member(first_name,last_name, member_email,is_leader, team_id) 
          VALUES ('FRANK','HANS','frank_hans@email.com',
          false, 
          (SELECT team_id FROM team WHERE team_name='TEAM C') );
INSERT INTO team_member(first_name,last_name, member_email,is_leader, team_id) 
          VALUES ('BOB','QUEENS','bob_queens@email.com',
          false, 
          (SELECT team_id FROM team WHERE team_name='TEAM C') );
COMMIT;
          
 SET autocommit = 1; 
          
-- SHOW VARIABLES WHERE Variable_name='autocommit';