-- topic:
-- Using MySQL Workbench to practice on the concept
-- START TRANSACTION, COMMIT and ROLLBACK
-- MAKE SURE your database already has complete Team D and Team D member records first
-- before using this SQL script file to appreciate TRANSACTION concept.
START TRANSACTION;
-- Once the DB engine sees the START TRANSACTION instruction:
-- All the 4 commands "after" the START TRANSACTION command
-- will be treated by the database engine as a single unit of work.
-- Which means that, if any of the SQL command has error,
-- you can execute the ROLLBACK command to "rollback" to the original state.
-- (nothing has happened)
INSERT INTO team(team_name, team_description)
      VALUES ('TEAM C','TEAM C DESCRIPTION' );
INSERT INTO team_member(first_name,last_name, member_email,is_leader, team_id) 
          VALUES ('FRED','HANS','fred_hans@email.com',
          true, 
          (SELECT team_id FROM team WHERE team_name='TEAM C') );
INSERT INTO team_member(first_name,last_name, member_email,is_leader, team_id) 
          VALUES ('FRANK','HANS','frank_hans@email.com',
          false, 
          (SELECT team_id FROM team WHERE team_name='TEAM C') );
INSERT INTO team_member(first_name,last_name, member_email,is_leader, team_id) 
          VALUES ('BOB','QUEENS','bob_queens@email.com',
          false, 
          (SELECT team_id FROM team WHERE team_name='TEAM C') );

-- If you want the database engine to ROLLBACK to the original state
-- (nothing has happened), then you need to use the SQL command
-- ROLLBACK;
ROLLBACK;

-- If you want the database engine to make all recent changes
-- permanent, then you need to use the SQL command
-- ROLLBACK;
COMMIT;
          
