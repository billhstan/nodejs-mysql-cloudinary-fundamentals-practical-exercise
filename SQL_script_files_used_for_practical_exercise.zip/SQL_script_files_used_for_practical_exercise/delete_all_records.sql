DELETE FROM team_member;
DELETE FROM team;


DELETE FROM team_member WHERE team_id = (SELECT team_id FROM team WHERE team_name='TEAM C');
DELETE FROM team WHERE team_name='TEAM C';


DELETE FROM team_member WHERE team_id = (SELECT team_id FROM team WHERE team_name='TEAM D');
DELETE FROM team WHERE team_name='TEAM D';