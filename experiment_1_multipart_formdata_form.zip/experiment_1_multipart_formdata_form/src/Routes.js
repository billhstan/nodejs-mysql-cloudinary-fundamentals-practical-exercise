import React from "react";
import { Fragment } from 'react';
import Container from 'react-bootstrap/Container';
import { render } from "react-dom"
import {
  Route,
  BrowserRouter as Router,
  Switch,
  Redirect,
} from 'react-router-dom';

import HomePage from './Pages/HomePage/HomePage';
import SiteMenu from './Elements/SiteMenu/SiteMenu';
import Experiment1 from './Pages/Experiment1/Experiment1';
import Experiment2 from './Pages/Experiment2/Experiment2';
import ExperimentA1 from './Pages/ExperimentA1/ExperimentA1';

const Routes = (props) => (

  
<Router {...props}>

    
    <Container>
    <SiteMenu />
    <Switch>
      <Route path="/home">
        <HomePage />
      </Route>
      <Route path="/experiment1">
        <Experiment1 />
      </Route>
      <Route path="/experiment2">
        <Experiment2 />
      </Route>
      <Route path="/experimentA1">
        <ExperimentA1  />
      </Route>
     </Switch>
    </Container>

</Router>
 

);

export default Routes;
