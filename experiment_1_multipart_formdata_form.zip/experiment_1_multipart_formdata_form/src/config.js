// src/config.js
const config = {
    baseUrl: "http://localhost:4000/api", // No trialing slash here
  };
export default config;