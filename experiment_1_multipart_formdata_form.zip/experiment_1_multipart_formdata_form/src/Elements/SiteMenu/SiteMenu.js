import React, { useState } from "react";
import {
	Navbar,
	NavItem,NavDropdown
} from 'react-bootstrap';
import Dropdown from 'react-bootstrap/Dropdown';
import Nav from 'react-bootstrap/Nav';
import { NavLink, withRouter, useHistory } from "react-router-dom";

const SiteMenu = () => {
	return (

		<Navbar expand="lg">
		<Navbar.Brand href="/">Experiments</Navbar.Brand>
		<Navbar.Toggle aria-controls="basic-navbar-nav"/>
		<Navbar.Collapse id="basic-navbar-nav">

		 <NavDropdown title="Experiments" id="navbarScrollingDropdown">
        <NavDropdown.Item href="/experiment1">Experiment 1 - Create Team</NavDropdown.Item>

        <NavDropdown.Divider />
        <NavDropdown.Item href="/experiment2">Experiment 2 - View Teams</NavDropdown.Item>
      </NavDropdown>
		</Navbar.Collapse>
	   </Navbar>
	
	); // End of return
}; // End of const SiteMenu = { ...

export default SiteMenu;
