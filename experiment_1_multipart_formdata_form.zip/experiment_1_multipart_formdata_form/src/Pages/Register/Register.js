import React, { useState, useEffect } from 'react';
import styles from './Register.module.css';
import { useForm } from 'react-hook-form';
import { Link } from 'react-router-dom';
import { Input, Form, Label, Grid, Header, Button, Image } from 'semantic-ui-react'
const Register = () => {

  const { register, handleSubmit, formState: { errors }, watch } = useForm();

  const [message, setMessage] = useState();
  // You need the loading state so that the Login button can
  // effectively show the button label or 'loading....' 
  const [loading, setLoading] = useState(false);


  // Handle the form submit of Registration form
  const onSubmit = (data, e) => {
    console.dir(data);
    setMessage({
      data: 'Registration is in progress...',
      type: 'alert-warning',
    });
    setLoading(true);
    //More code should be placed here to make a REST API call
    //and send the collected form data to the REST API. 
  }// End of onSubmit

  return (

    <Form onSubmit={handleSubmit(onSubmit)} noValidate autoComplete="off">

      <Grid fluid columns={2} textAlign="left" style={{ height: '100%', borderStyle: 'solid', borderColor: 'red' }} verticalAlign="middle">

        <Grid.Row>
          <Grid.Column width={16} style={{  borderStyle: 'solid', borderColor: 'blue' }}>
            <Header as="h2" color="teal" textAlign="center">
              <Image src="/images/logo.png" /> Register with us
      </Header>
          </Grid.Column>
        </Grid.Row>
        <Grid.Row>
          <Grid.Column>
            {/*I purposely changed the id property to id="email1". The
              modification did not break the validation logic.*/}
            {/* fluid = Set maximum width */}
            {/* size = Set maximum width */}
            <Form.Field error={(errors.email) ?
              errors.email.message : null}
              style={{ borderStyle: 'solid', borderColor: 'black' }}>
              <Input
                fluid
                id="email"
                label={{ icon: 'asterisk' }}
                labelPosition="left corner"
                size="small"
                error={(errors.email) ?
                  errors.email.message : null}
                type="email"
                placeholder="Email address"
                {...register('email', {
                  required: {
                    value: true,
                    message: 'Please enter your email address',
                  },
                  pattern: {
                    value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i,
                    message: 'Enter a valid email address',
                  },
                  minLength: {
                    value: 6,
                    message: 'Minimum 6 characters are allowed',
                  },
                  maxLength: {
                    value: 50,
                    message: 'Maximum 50 characters are allowed',
                  },
                })}
              />
              {/**
               * we provide validation configuration for email field above
               * error message are displayed with code below
               */}
              {errors.email &&
                <Label  floating  style={{width:'200px'}}  size="small" pointing="left"  color='red'>{errors.email.message}
                </Label>}
            </Form.Field>
          </Grid.Column>
        </Grid.Row>
        <Grid.Row>
          <Grid.Column width={6} >
            <Form.Field error={(errors.firstName) ?
              errors.firstName.message : null}
              style={{ borderStyle: 'solid', borderColor: 'black' }}>
              <Input
                id="firstName"
                fluid
                type="text"
                size="small"
                label={{ icon: 'asterisk' }}
                labelPosition="left corner"
                error={(errors.firstName) ?
                  errors.firstName.message : null}

                placeholder="First name"
                {...register('firstName', {
                  required: {
                    value: true,
                    message: 'Please enter your first name.',
                  },
                  minLength: {
                    value: 1,
                    message: 'First name is required.',
                  },
                  maxLength: {
                    value: 50,
                    message: 'Maximum 50 characters are allowed',
                  },
                })}
              />
              {errors.firstName &&
                <Label  floating  size="small"  style={{width:'100px'}} pointing="left"  color='red'>{errors.firstName.message}
                </Label>}
            </Form.Field>
          </Grid.Column>
          <Grid.Column width={2}></Grid.Column>
          <Grid.Column width={6} >
            <Form.Field error={(errors.lastName) ?
              errors.lastName.message : null} style={{ borderStyle: 'solid', borderColor: 'black' }}>
              <Input
                id="lastName"
                type="text"
                label={{ icon: "asterisk" }}
                size="small"
                labelPosition="left corner"
                fluid
                error={(errors.lastName) ?
                  errors.lastName.message : null}
                placeholder="Last name."

                {...register('lastName', {
                  required: {
                    value: true,
                    message: 'Please enter your last name',
                  },
                  minLength: {
                    value: 1,
                    message: 'Last name is required.',
                  },
                  maxLength: {
                    value: 50,
                    message: 'Maximum 50 characters are allowed',
                  },
                })}
              />
              {errors.lastName &&
                <Label floating  size="small" style={{width:'100px'}} pointing="left" color='red'>{errors.lastName.message}
                </Label>}
            </Form.Field>

          </Grid.Column>
          <Grid.Column width={2}></Grid.Column>
        </Grid.Row>
        <Grid.Row>
          <Grid.Column>
            <Form.Field error={(errors.password) ?
              errors.password.message : null} style={{ borderStyle: 'solid', borderColor: 'black' }}>
              <Input
                type="password"
                id="password"
                label={{ icon: "asterisk" }}
                size="small"
                labelPosition="left corner"
                fluid
                error={(errors.password) ?
                  errors.password.message : null}
                placeholder="Password"
                {...register('password', {
                  required: {
                    value: true,
                    message: 'Please enter password',
                  },
                  minLength: {
                    value: 6,
                    message: 'Minimum 5 characters are allowed',
                  },
                  maxLength: {
                    value: 50,
                    message: 'Maximum 50 characters are allowed',
                  },
                })}
              />
              {errors.password && (
                <Label  floating  style={{width:'200px'}}  size="small" pointing="left"  color='red'>
                  {errors.password.message}
                </Label>
              )}

            </Form.Field>
          </Grid.Column>
        </Grid.Row>

        <Grid.Row>
          <Grid.Column>
            <Form.Field error={(errors.confirmPassword) ?
              errors.confirmPassword.message : null} style={{ borderStyle: 'solid', borderColor: 'black' }}>
              <Input
                type="password"
                id="confirmPassword"
                label={{ icon: "asterisk" }}
                size="small"
                labelPosition="left corner"
                fluid
                error={(errors.password) ?
                  errors.password.message : null}

                placeholder="Confirm password"
                {...register('confirmPassword', {
                  validate: (value) => value === watch('password') || "Passwords don't match.",
                  required: {
                    value: true,
                    message: 'Please enter password',
                  },
                  minLength: {
                    value: 6,
                    message: 'Minimum 5 characters are allowed',
                  },
                  maxLength: {
                    value: 50,
                    message: 'Maximum 255 characters are allowed',
                  },
                })}
              />
              {errors.confirmPassword && (
                <Label floating  style={{width:'200px'}} size="small" pointing="left"  color='red'>
                  {errors.confirmPassword.message}
                </Label>
              )}
            </Form.Field>

          </Grid.Column>
        </Grid.Row>
        <Grid.Row>
          <Grid.Column width={16} textAlign="right">
          <Button primary>Register</Button>
        <Button as={Link} secondary to="/login">
           Cancel
        </Button>       
          </Grid.Column>
        </Grid.Row>

 


      </Grid>

    </Form>



  );
};

export default Register;