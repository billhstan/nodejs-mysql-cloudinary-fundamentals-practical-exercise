import ReactDOM from "react-dom";
import React, { useState, useEffect,  useRef } from 'react';
import {Card,Spinner} from "react-bootstrap";
import styles from "./Experiment2.module.css";
import config from '../../config.js';
import axios from 'axios';
import { List, CellMeasurer, CellMeasurerCache } from "react-virtualized";
import { ToastContainer, toast } from 'react-toastify';

const Experiment2 = () => {
	const [teamData, setTeamData] = useState([]);
    const [loading, setLoading]=useState(true);	// You need the loading state so that the Spinner
	// can work.

	//https://github.com/edmilson-dk/react-virtualize-list-example/blob/main/src/GoodListDataComponentCellMeasurer.js
	//https://stackoverflow.com/questions/51826454/how-to-use-cellmeasurer-in-react-virtualized-table
	const cache = new CellMeasurerCache({
		fixedWidth: true,
		defaultHeight: 300
	  });
	  
	  function renderRow({ index, key, style, parent }) {
		
		return (
		  <CellMeasurer
			key={key}
			cache={cache}
			parent={parent}
			columnIndex={0}
			rowIndex={index}>
				
			<div style={style} className="row" >
			  <div className="col col-md-12" >
			  <Card  className="card text-white bg-dark mb-3 col-md-12" >
					<Card.Body>
						<Card.Title>{teamData[index].name}</Card.Title>
			
			  <img 
					style={{ width: 250, margin: "20px" }}
					src={`${config.baseUrl}/resources/?url=${teamData[index].images[0].url}`} />
							<img
					style={{ width: 250, margin: "20px" }}
					src={`${config.baseUrl}/resources/?url=${teamData[index].images[1].url}`}
				/>
			</Card.Body>
		</Card>
			</div>
			</div>
		  </CellMeasurer>
		);
	  }
	
	  /*
	function renderRow({ index, key, style, parent, rowData }) {
		//console.log(style); //Curious what this style is. Have not looked into it.
		return (
			<CellMeasurer
				key={key}
				cache={cache}
				parent={parent}
				columnIndex={0}
				rowIndex={index}
			>
				<>
					<div class="row w-100">
						<div class="col col-md-4"
							style={{
								
								borderBottomWidth: "2px",
								borderBottomColor: "black",
							}}
						>
							{rowData.name}
						</div>
						<div class="col col-md-4" style={{ borderBottomWidth: "2px", borderBottomColor: "black" }}>
							{" "}
							<img
								style={{ width: 150, margin: "20px" }}
								src={`${config.baseUrl}/resources/?url=${rowData.images[0].url}`}
							/>
						</div>
						<div class="col col-md-4"  style={{ borderBottomWidth: "2px", borderBottomColor: "black" }}>
							<img
								style={{ width: 150, margin: "20px" }}
								src={`${config.baseUrl}/resources/?url=${rowData.images[1].url}`}
							/>
						</div>
					</div>
				</>
			</CellMeasurer>
		);
	} */
	function renderHeaderRow({ }) {
		return (

				<>
                
					<div class="row">
						<div class="col col-md-4"
							style={{
								
								borderBottomWidth: "2px",
								borderBottomColor: "black",
							}}
						>
							Team Name
						</div>
						<div class="col col-md-8" style={{ borderBottomWidth: "2px", borderBottomColor: "black" }}>
							Submitted images
						</div>
					</div>
				</>

		);
	}


	useEffect(() => {
        
		axios
			.get(`${config.baseUrl}/teams`, {})
			.then((response) => {
				
				//Trying to find out where the array is nested.
				//Note that due to the json_object function usage in the SQL,
				//there is an additional data property associated with the JSON formatted string data.
				//console.log("Checking response.data.data");
                //console.log(response.data.data[1]);
				let records = [];
				response.data.data.forEach((element) => {
					let data = JSON.parse(element.data);
					data.changeStatus = false; //Not used in this user interface functionality.
					//The above changeStatus property is useful if the tabulated data is editable and
					//this property is managed to mark which record data was updated with a new value.
					records.push(data);
				});
            
				setTeamData(records);
               setLoading(false);
				
				//Inspect the final teamData information
                console.log('Check teamData');
				console.log(teamData);
                
			})
			.catch((error) => {
				console.log(error);
				toast.error('Something went wrong.');
			});
            
	}, []); //End of useEffect({function code,[]})

	/* The following two methods were not used */
	//The code remains here because the code works
	//but I faced issues in aligning the cell content
	//towards my expected outcome.
	//cellRendererForTeamName, cellRendererForTeamImages
	const cellRendererForTeamName = ({ cellData }) => {
		return (
			<div
				style={{
					display: "flex",
					justifyContent: "flex-start",
					alignItems: "flex-start",
					alignContent: "flex-start",
					color: "white",
					backgroundColor: "black",
					padding: "10px",
				}}
			>
				{cellData}
			</div>
		);
	};
	const cellRendererForTeamImages = ({ rowData }) => {
		return (
			<div
				style={{
					display: "flex",
					justifyContent: "flex-start",
					alignItems: "flex-start",
					alignContent: "flex-start",
					color: "white",
					backgroundColor: "lightblue",
					padding: "10px",
					margin: "20px",
				}}
			>
				<img
					style={{ width: 100, margin: "20px" }}
					src={`${config.baseUrl}/resources/?url=${rowData.images[0].url}`}
				/>
				<br />
				<img
					style={{ width: 100, margin: "20px" }}
					src={`${config.baseUrl}/resources/?url=${rowData.images[1].url}`}
				/>
				<br />
			</div>
		);
	};
	/*
          <Column label="Team name"     style={{
            verticalAlign:'top' }} cellRenderer={cellRendererForTeamName}  dataKey="name" width={200} />
          <Column
            cellRenderer={cellRendererForTeamImages} width={500} dataKey="images"/>
    */
	return (
		// <> is a short syntax for <React.Fragment> and can be used instead of a wrapping div
		<>
			<div
				className="container container-fluid"
				style={{ border: "solid 2px black" }}
			>
				<h5>Experiment reactjs-virtualized library</h5>
				<Card className="col-md-12 small">
					<Card.Body>
						<Card.Title>Experiment Log</Card.Title>
						<Card.Subtitle className="mb-2 text-muted">
							14 Aug 2021 Saturday 11 AM
						</Card.Subtitle>
						<Card.Text>
							<p style={{ margin: 0 }} className="small">
								Managed to experiment resizing of row for virtualization effects.
							</p>
							<p style={{ margin: 0 }} className="small">
								Managed to bind the list with server-side response data.
							</p>
							<p style={{ margin: 0 }} className="small text-success">
								It is possible to integrate the list to the Bootstrap css.
							</p>
							<p style={{ margin: 0 }} className="small text-danger">
								Note that, the images are developed by using SRC=&lt;REST API call&gt;. Due to 
								how the images are developed, the formula which pre-calculates the height of
								each row is NOT ACCURATE. <b>Need</b> another technique to load images.
							</p>
							<p style={{ margin: 0 }} className="small text-danger">
								Did not continue to dive in further, to find out how to support search,
								filter, "Manage button" for each list row etc.
							</p>
							<p style={{ margin: 0 }} className="small text-danger">
								Unable to center the list.
							</p>
							<p style={{ margin: 0 }} className="small text-success">
								Note that, there are other libraries such as React-Table which is also
								useful.
							</p>
							<p style={{ margin: 0 }} className="small text-success">
								Besides Bootstrap css, one good CSS library is AtlasKit{" "}
							</p>
						</Card.Text>
						<Card.Link
							className="small"
							href="https://atlaskit.atlassian.com/"
							target="_blank"
						>
							https://atlaskit.atlassian.com/
						</Card.Link>
					</Card.Body>
				</Card>
				<ToastContainer position="top-center" />
               { loading ?(
    
        <Spinner animation="border" variant="primary" />
    ):(
		
						<div className="row">
      <List
        
        height={600}
        rowCount={teamData.length}
        deferredMeasurementCache={cache}
        rowHeight={390}
        rowRenderer={renderRow}
		
        width={1400}
      />
    </div>
							

    )}
			</div>
		</>
	);
};

export default Experiment2;
