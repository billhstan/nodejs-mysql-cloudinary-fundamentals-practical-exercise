import ReactDOM from "react-dom";
import React, { useState, useEffect } from "react";
import { Button } from "react-bootstrap";
import { ToastContainer, toast } from 'react-toastify';
import { Formik, Field, Form, ErrorMessage } from "formik";
//Important reference:https://www.codegrepper.com/code-examples/whatever/formik+validate+on+button+click
import * as Yup from "yup";
const Experiment1 = () => {
    //Setting up the CONST variables here did not helped me to use them
    //for the Yup configuration.
    const FILE_SIZE = 160 * 1024;
    const SUPPORTED_FORMATS = [
      'image/jpg',
      'image/jpeg',
      'image/gif',
      'image/png'
    ];

	return (
		// <> is a short syntax for <React.Fragment> and can be used instead of a wrapping div
		<>
        <h5>Experiment multipart/form-data content type data submission to backend</h5>
        <ToastContainer position="top-center" />
			<Formik
				initialValues={{
					teamName: 'BLUE BLOOD',
					teamDescription: 'Dedicated in building systems for voluntary organisations',
					firstName1: 'RED',
					lastName1: 'KINGS',
					email1: 'red_kings@email.com',
					isLeader1: 'true',
					firstName2: 'SEED',
					lastName2:'KINGS',
					email2: 'seed_kings@email.com',
					isLeader2: 'false',
					firstName3: 'TED',
					lastName3: 'KINGS',
					email3: 'ted_kings@email.com',
					isLeader3: 'false',
					file1: '',
					file2: '',
				}}
				validationSchema={Yup.object({
					teamName: Yup.string()
						.max(30, "Must be 30 characters or less")
						.required("Required"),
					teamDescription: Yup.string()
						.max(200, "Must be 200 characters or less")
						.required("Required"),
					firstName1: Yup.string()
						.max(15, "Must be 15 characters or less")
						.required("Required"),
					lastName1: Yup.string()
						.max(20, "Must be 20 characters or less")
						.required("Required"),
					email1: Yup.string().email("Invalid email address").required("Required"),
					isLeader1: Yup.string().required("Required"),
					firstName2: Yup.string()
						.max(15, "Must be 15 characters or less")
						.required("Required"),
					lastName2: Yup.string()
						.max(20, "Must be 20 characters or less")
						.required("Required"),
					email2: Yup.string().email("Invalid email address").required("Required"),
					isLeader2: Yup.string().required("Required"),
					firstName3: Yup.string()
						.max(15, "Must be 15 characters or less")
						.required("Required"),
					lastName3: Yup.string()
						.max(20, "Must be 20 characters or less")
						.required("Required"),
					email3: Yup.string().email("Invalid email address").required("Required"),
					isLeader3: Yup.string().required("Required"),
                    file1: Yup
                    .mixed()
                    .required("A file is required")
                    .test(
                      "fileSize",
                      "File too large",
                      value => value && value.size <= (160 * 1024)
                    )
                    .test(
                      "fileFormat",
                      "Unsupported Format",
                      value => value && [
                        'image/jpg',
                        'image/jpeg',
                        'image/gif',
                        'image/png'
                      ].includes(value.type)
                    ),
                    /* https://codesandbox.io/s/4wrrx8qok0?file=/src/App.js:1147-1488 */
                    file2: Yup
                    .mixed()
                    .required("A file is required")
                    .test(
                      "fileSize",/* When I was working on the validation flow, I noticed that, it checks for size first */
                      "File too large",
                      value => value && value.size <= (1024 * 1024)
                    )
                    .test(
                      "fileFormat",
                      "Unsupported Format",
                      value => value && [
                        'image/jpg',
                        'image/jpeg',
                        'image/gif',
                        'image/png'
                      ].includes(value.type)
                    )
				})}
				onSubmit={async (values, actions) => {
                    console.log(values);
                    let data = new FormData();
                    //The FormData object preparation is the same as Postman.
  data.append('file', values.file1);
  data.append('file', values.file2);
  data.append('firstName', values.firstName1);
  data.append('lastName', values.lastName1);
  data.append('email', values.email1);
  data.append('isLeader', values.isLeader1);
  data.append('firstName', values.firstName2);
  data.append('lastName', values.lastName2);
  data.append('email', values.email2);
  data.append('isLeader', values.isLeader2);
  data.append('firstName', values.firstName3);
  data.append('lastName', values.lastName3);
  data.append('email', values.email3);
  data.append('isLeader', values.isLeader3);
  data.append('teamName', values.teamName);
  data.append('teamDescription',values.teamDescription);
  try{
  const response = await fetch('http://localhost:4000/api/teams/detail', {
    method: "post",
    headers: new Headers({
      Accept: "application/json",
       Authorization: "Bearer " + 'tokensample', 
    /* I was stuck here for 2 hours because I don't need to specify the encoding type 
    for formdata. Reference: https://stackoverflow.com/questions/46640024/how-do-i-post-form-data-with-fetch-api */
      /*'Content-Type': 'multipart/form-data'*/
    }),
    body: data,
  })
    .then(function(response) {return response.json()})
    .then(function(data) {
        //console.dir(data);
        //console.dir(data.status);
        return data;
      })
    .catch(function (error) {return(error)});
    
    console.log('Inspect what fetch method returns');
    console.log(response);
    if (response.status=='success'){
        toast.success('You have saved the team and file data');
    }
    }catch(error){
        console.log(error);
        toast.error('Something went wrong. Please try again.');
    }
    
				}}
			>{/*I don't need the props thing in the code if I don't intend to use setFieldValue for file input. handleChange won't work */}
            {/*https://codersingh.in/image-upload-using-formik/*/ }
            {props => (
				<Form>
                <div className="form-group row mb-2">
                        <h4>Team</h4>
                    </div>                 
					<div class="form-group row mb-2">
						<label htmlFor="teamName" class="control-label col-sm-2 small">Name</label>
                        <div class="col-sm-8">
						<Field
							name="teamName"
							className="form-control form-control-sm"
							type="text"
							placeholder="Team name"
						/>
						<ErrorMessage name="teamName" >
                        {errMsg => <div class="alert alert-light small p-0 m-1" >{errMsg}</div>}
                            </ErrorMessage>
                        </div>
					</div>

					<div class="form-group row mb-2">
						<label htmlFor="teamDescription" class="control-label col-sm-2 small">Team description</label>
                        <div class="col-sm-8">
						<Field
							name="teamDescription"
							as="textarea"
							placeholder="Team description"
                            className="form-control form-control-sm"
						/>
						<ErrorMessage name="teamDescription" >
              
                        {errMsg => <div class="alert alert-light small p-0 m-1" >{errMsg}</div>}
                 
                        </ErrorMessage>
                        </div>
					</div>
                    <div class="form-group row mb-2">
                        <h4>Member 1</h4>
                    </div>
					<div class="form-group row mb-2">
						<label htmlFor="firstName1" class="control-label col-sm-2 small">First name</label>
                        <div class="col-sm-8">
						<Field
							name="firstName1"
							type="text"
							placeholder="First name"
							className="form-control form-control-sm"
						/>
						<ErrorMessage name="firstName1"  >
                        {errMsg => <div class="alert alert-light small p-0 m-1" >{errMsg}</div>}
                            </ErrorMessage>
                        </div>
					</div>
					<div class="form-group row mb-2">
						<label htmlFor="lastName1" class="control-label col-sm-2 small">Last name</label>
                        <div class="col-sm-8">
						<Field name="lastName1" className="form-control" type="text" className="form-control form-control-sm" placeholder="Last name" />
						<ErrorMessage name="lastName1" >
                        {errMsg => <div className="alert alert-light small p-0 m-1" >{errMsg}</div>}
                            </ErrorMessage>
                        </div>
					</div>
					<div class="form-group row mb-2">
						<label htmlFor="email1" class="control-label col-sm-2 small">Email</label>
                        <div class="col-sm-8">
						<Field name="email1" type="text" placeholder="Email" className="form-control form-control-sm" />
						<ErrorMessage name="email1"  >
                        {errMsg => <div class="alert alert-light small p-0 m-1" >{errMsg}</div>}
                            </ErrorMessage>
                        </div>
					</div>
					<div class="form-group row mb-2">
                        {/* Reference for defining a dropdown listbox input interface */}
                        {/* https://formik.org/docs/api/field */}
						<label htmlFor="isLeader1" class="control-label col-sm-2 small">Team member role</label>
                        <div class="col-sm-8">
						<Field as="select" name="isLeader1" className="form-control form-control-sm">
							<option value="">Team member role</option>
							<option value="true">Team leader</option>
							<option value="false">Team member</option>
						</Field>
						<ErrorMessage name="isLeader1"  >
                        {errMsg => <div className="alert alert-light small p-0 m-1" >{errMsg}</div>}
                            </ErrorMessage>
                        </div>
					</div>


                    <div class="form-group row mb-2">
                        <h4>Member 2</h4>
                    </div>
					<div class="form-group row mb-2">
						<label htmlFor="firstName2" class="control-label col-sm-2 small">First name</label>
                        <div class="col-sm-8">
						<Field
							name="firstName2"
							type="text"
							placeholder="First name"
							className="form-control form-control-sm"
						/>
						<ErrorMessage name="firstName2"  >
                        {errMsg => <div class="alert alert-light small p-0 m-1" >{errMsg}</div>}
                            </ErrorMessage>
                        </div>
					</div>
					<div class="form-group row mb-2">
						<label htmlFor="lastName2" class="control-label col-sm-2 small">Last name</label>
                        <div class="col-sm-8">
						<Field name="lastName2" className="form-control" type="text" className="form-control form-control-sm" placeholder="Last name" />
						<ErrorMessage name="lastName2" >
                        {errMsg => <div class="alert alert-light small p-0 m-1" >{errMsg}</div>}
                            </ErrorMessage>
                        </div>
					</div>
					<div class="form-group row mb-2">
						<label htmlFor="email2" class="control-label col-sm-2 small">Email</label>
                        <div class="col-sm-8">
						<Field name="email2" type="text" placeholder="Email" className="form-control form-control-sm" />
						<ErrorMessage name="email2"  >
                        {errMsg => <div class="alert alert-light small p-0 m-1" >{errMsg}</div>}
                            </ErrorMessage>
                        </div>
					</div>
					<div class="form-group row mb-2">
                        {/* Reference for defining a dropdown listbox input interface */}
                        {/* https://formik.org/docs/api/field */}
						<label htmlFor="isLeader2" class="control-label col-sm-2 small">Team member role</label>
                        <div class="col-sm-8">
						<Field as="select" name="isLeader2" className="form-control form-control-sm">
							<option value="">Team member role</option>
							<option value="true">Team leader</option>
							<option value="false">Team member</option>
						</Field>
						<ErrorMessage name="isLeader2"  >
                        {errMsg => <div class="alert alert-light small p-0 m-1" >{errMsg}</div>}
                            </ErrorMessage>
                        </div>
					</div>

                    <div class="form-group row mb-2">
                        <h4>Member 3</h4>
                    </div>
					<div class="form-group row mb-2">
						<label htmlFor="firstName3" class="control-label col-sm-2 small">First name</label>
                        <div class="col-sm-8">
						<Field
							name="firstName3"
							type="text"
							placeholder="First name"
							className="form-control form-control-sm"
						/>
						<ErrorMessage name="firstName3"  >
                        {errMsg => <div class="alert alert-light small p-0 m-1" >{errMsg}</div>}
                            </ErrorMessage>
                        </div>
					</div>
					<div class="form-group row mb-2">
						<label htmlFor="lastName3" class="control-label col-sm-2 small">Last name</label>
                        <div class="col-sm-8">
						<Field name="lastName3" className="form-control" type="text" className="form-control form-control-sm" placeholder="Last name" />
						<ErrorMessage name="lastName3" >
                        {errMsg => <div class="alert alert-light small p-0 m-1" >{errMsg}</div>}
                            </ErrorMessage>
                        </div>
					</div>
					<div className="form-group row mb-2">
						<label htmlFor="email3" class="control-label col-sm-2 small">Email</label>
                        <div class="col-sm-8">
						<Field name="email3" type="text" placeholder="Email" className="form-control form-control-sm" />
						<ErrorMessage name="email3"  >
                        {errMsg => <div className="alert alert-light small p-0 m-1" >{errMsg}</div>}
                            </ErrorMessage>
                        </div>
					</div>
					<div class="form-group row mb-2">
                        {/* Reference for defining a dropdown listbox input interface */}
                        {/* https://formik.org/docs/api/field */}
						<label htmlFor="isLeader3" class="control-label col-sm-2 small">Team member role</label>
                        <div class="col-sm-8">
						<Field as="select" name="isLeader3" className="form-control form-control-sm">
							<option value="">Team member role</option>
							<option value="true">Team leader</option>
							<option value="false">Team member</option>
						</Field>
						<ErrorMessage name="isLeader3"  >
                        {errMsg => <div class="alert alert-light small p-0 m-1" >{errMsg}</div>}
                            </ErrorMessage>
                        </div>
					</div>

					<div class="form-group row mb-2">

						<label htmlFor="file1" class="control-label col-sm-2 small">Team logo picture</label>
                        <div class="col-sm-8">
						<input type="file" name="file1" class="form-control form-control-sm"   
                        onChange={(event) =>{console.dir(event.target.files[0]);
    props.setFieldValue("file1", event.target.files[0]);
  }} />
						<ErrorMessage name="file1"  >
                        {errMsg => <div class="alert alert-light small p-0 m-1" >{errMsg}</div>}
                            </ErrorMessage>
                        </div>
					</div>
                    
					<div class="form-group row mb-2">

<label htmlFor="file1" class="control-label col-sm-2 small">Team group photo</label>
<div class="col-sm-8">
<input type="file" name="file2" class="form-control form-control-sm"   
onChange={(event) =>{ console.dir(event.target.files[0]);
props.setFieldValue("file2", event.target.files[0]);
}} />
<ErrorMessage name="file2"  >
{errMsg => <div class="alert alert-light small p-0 m-1" >{errMsg}</div>}
    </ErrorMessage>
</div>
</div>

					<Button type="submit">Submit</Button>
				</Form>
            )}
			</Formik>
		</>
	);
};

export default Experiment1;
