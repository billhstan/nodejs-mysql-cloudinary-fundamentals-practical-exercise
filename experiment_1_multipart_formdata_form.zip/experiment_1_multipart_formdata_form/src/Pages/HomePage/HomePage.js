import React, { Component } from 'react'
import styles from "./HomePage.module.css";
import Container from 'react-bootstrap/Container';

const HomePage = () => (
    <Container>
      <h1 className={styles.HomepagePrimaryHeader}>ReactJS Experiments</h1>
      <h2 className={styles.HomepageSecondaryHeader}>A project system which experiments ReactJS App with ReactJS Boostrap</h2>
    </Container>
  )

  export default HomePage;