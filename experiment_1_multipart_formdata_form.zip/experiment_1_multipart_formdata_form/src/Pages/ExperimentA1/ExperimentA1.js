import ReactDOM from 'react-dom';
import React, { useState, useEffect, setValue } from 'react';
const ExperimentA1 = (props) => {
    //Set an initial state
    //The following command is working if...you did not apply props
    //const [count, setCount] = useState(0);
    //The following command is advisable, if you are using props
    const [ count, setCount ] = useState(props.count || 0)
    //https://stackoverflow.com/questions/44263915/how-to-specify-a-constructor-with-a-functional-component-fat-arrow-syntax
    //The discussion at StackOverFlow is useful for the above command's purpose.
    //Not using the above command will lead to error or infinite loop.
    
    //Inspect the props content
    console.log(props);
    // Similar to componentDidMount and componentDidUpdate for React class component
    useEffect(() => {
      //Gets called after component is re-rendered
      //Update the document title using the browser API
      document.title = `You've clicked ${count} times.`;
    });
  


    return (
      // <> is a short syntax for <React.Fragment> and can be used instead of a wrapping div
      <>
      <h3>Experiment useState and useEffect concepts by tracking a </h3>
        <p>You've clicked {count} times.</p>
        <button class="btn btn-secondary" onClick={() => setCount(count + 1)}>
          Click me
        </button>
      </>
    );
  }

  export default ExperimentA1;