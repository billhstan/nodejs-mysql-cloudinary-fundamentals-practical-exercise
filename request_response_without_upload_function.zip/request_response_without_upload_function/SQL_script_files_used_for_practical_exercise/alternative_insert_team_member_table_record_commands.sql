INSERT INTO team(team_name, team_description)
      VALUES ('SOFT ZOMBIE','We develop softwares for people to edit cartonavigation_categoryons.
    We aim to develop artificial intelligent tools to help users
    bring their imagination into the digital world in minutes.' );
SET @newTeamId = LAST_INSERT_ID();
INSERT INTO team_member(first_name,last_name, member_email,is_leader, team_id)
          VALUES ('AMANDA','KING','amanda_king@email.com',
          true,
          @newTeamId );
INSERT INTO team_member(first_name,last_name, member_email,is_leader, team_id)
          VALUES ('AMY','KING','amy_king@email.com',
          false,
          @newTeamId );
INSERT INTO team_member(first_name,last_name, member_email,is_leader, team_id)
          VALUES ('ALICE','KING','alice_king@email.com',
          false,
          @newTeamId );