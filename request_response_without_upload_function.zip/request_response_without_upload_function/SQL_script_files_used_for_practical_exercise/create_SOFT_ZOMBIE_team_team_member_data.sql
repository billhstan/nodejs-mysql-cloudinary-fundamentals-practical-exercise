INSERT INTO team(team_name, team_description)
  VALUES ('SOFT ZOMBIE','We develop softwares for people to edit cartoons. We aim to develop artificial intelligent tools to help users bring their imagination into the digital world in minutes.' );

INSERT INTO team_member(first_name,last_name, member_email,is_leader, team_id)
  VALUES ('AMANDA','KING','amanda_king@email.com',true, (SELECT team_id FROM team WHERE team_name='SOFT ZOMBIE') );

INSERT INTO team_member(first_name,last_name, member_email,is_leader, team_id)
  VALUES ('AMY','KING','amy_king@email.com',false, (SELECT team_id FROM team WHERE team_name='SOFT ZOMBIE') );

INSERT INTO team_member(first_name,last_name, member_email,is_leader, team_id)
  VALUES ('ALICE','KING','alice_king@email.com',false, (SELECT team_id FROM team WHERE team_name='SOFT ZOMBIE') );

SELECT team.team_id, team.team_name, team_member.team_member_id, team_member.first_name, 
team_member.last_name, team_member.is_leader, team_member.member_email 
FROM team INNER JOIN team_member ON team.team_id = team_member.team_id;

SELECT team.team_id, team.team_name, team_member.team_member_id, 
team_member.first_name, team_member.last_name, 
IF (team_member.is_leader,'team leader','team member') 'team role',
 team_member.member_email FROM team 
INNER JOIN team_member ON team.team_id = team_member.team_id;


