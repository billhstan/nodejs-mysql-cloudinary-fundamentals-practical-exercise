DROP DATABASE IF EXISTS request_response_db;
Create Database request_response_db CHARACTER SET latin1 COLLATE latin1_general_ci;
Use request_response_db;
 CREATE TABLE team(
     team_id int NOT NULL AUTO_INCREMENT,
     team_name varchar(200) NOT NULL,
     team_description varchar(200) NOT NULL,
     PRIMARY KEY (team_id),
     UNIQUE(team_name)
)AUTO_INCREMENT=1;   

CREATE TABLE team_member(
     team_member_id int NOT NULL AUTO_INCREMENT,
     first_name varchar(100) NOT NULL,
     last_name varchar(100) NOT NULL,
     member_email varchar(200) NOT NULL,
     is_leader boolean NOT NULL,
     team_id int NOT NULL,
     PRIMARY KEY (team_member_id),
     UNIQUE(member_email),
	 FOREIGN KEY (team_id) REFERENCES team(team_id) 
)AUTO_INCREMENT=1;   

INSERT INTO team(team_name, team_description)
  VALUES ('BLUE BLOOD','Passionate in developing libraries which helps the community to build animation features.' );
INSERT INTO team(team_name, team_description)
  VALUES ('SYNTAX ERROR','We code to help people save time. Our strength leans towards secure coding best practices to fortify the backend' );
INSERT INTO team_member(first_name,last_name, member_email,is_leader, team_id)
  VALUES ('JOE','DASH','joe_dash@email.com',true, (SELECT team_id FROM team WHERE team_name='BLUE BLOOD') );
  INSERT INTO team_member(first_name,last_name, member_email,is_leader, team_id)
  VALUES ('JASON','DASH','jason_dash@email.com',false, (SELECT team_id FROM team WHERE team_name='BLUE BLOOD') );
    INSERT INTO team_member(first_name,last_name, member_email,is_leader, team_id)
  VALUES ('JIM','DASH','jim_dash@email.com',false, (SELECT team_id FROM team WHERE team_name='BLUE BLOOD') );
  INSERT INTO team_member(first_name,last_name, member_email,is_leader, team_id)
  VALUES ('RICK','ABLE','rick_able@email.com',true, (SELECT team_id FROM team WHERE team_name='SYNTAX ERROR') );
  INSERT INTO team_member(first_name,last_name, member_email,is_leader, team_id)
  VALUES ('ROBBERT','ABLE','robbert_able@email.com',false, (SELECT team_id FROM team WHERE team_name='SYNTAX ERROR') );
    INSERT INTO team_member(first_name,last_name, member_email,is_leader, team_id)
  VALUES ('ROBBY','ABLE','robby_able@email.com',false, (SELECT team_id FROM team WHERE team_name='SYNTAX ERROR') );
    

DROP USER IF EXISTS 'request_response_db_adminuser'@'localhost';
CREATE USER 'request_response_db_adminuser'@'localhost' IDENTIFIED BY 'password123';
GRANT ALL PRIVILEGES ON request_response_db.* TO 'request_response_db_adminuser'@'localhost';
ALTER USER 'request_response_db_adminuser'@'localhost' IDENTIFIED WITH mysql_native_password BY 'password123';
FLUSH PRIVILEGES;

