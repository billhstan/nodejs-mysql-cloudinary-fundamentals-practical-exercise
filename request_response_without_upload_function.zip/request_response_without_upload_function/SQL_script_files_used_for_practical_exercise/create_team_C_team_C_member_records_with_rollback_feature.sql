-- Tell the DB engine not to "automatically" commit any record changes (make the changes permanent)
-- until you "say so" by calling the COMMIT SQL command.
SET autocommit = 0; 

START TRANSACTION;
-- All the 4 commands "after" the START TRANSACTION command
-- will be treated by the database engine as a single unit of work.
-- Which means that, if any of the SQL command has error,
-- you can execute the ROLLBACK command to "rollback" to the original state.
-- (nothing has happened)
INSERT INTO team(team_name, team_description)
      VALUES ('TEAM C','TEAM C DESCRIPTION' );
INSERT INTO team_member(first_name,last_name, member_email,is_leader, team_id) 
          VALUES ('FRED','HANS','fred_hans@email.com',
          true, 
          (SELECT team_id FROM team WHERE team_name='TEAM C') );
INSERT INTO team_member(first_name,last_name, member_email,is_leader, team_id) 
          VALUES ('FRANK','HANS','frank_hans@email.com',
          false, 
          (SELECT team_id FROM team WHERE team_name='TEAM C') );
INSERT INTO team_member(first_name,last_name, member_email,is_leader, team_id) 
          VALUES ('BOB','QUEENS','bob_queens@email.com',
          false, 
          (SELECT team_id FROM team WHERE team_name='TEAM C') );

-- If you want the database engine to ROLLBACK to the original state
-- (nothing has happened), then you need to use the SQL command
-- ROLLBACK;
ROLLBACK;

-- You don't need to use the COMMIT SQL command to tell
-- the database engine to commit the changes
-- if the autocommit is true;
COMMIT;
          
SET autocommit = 1; 
          
-- SHOW VARIABLES WHERE Variable_name='autocommit';