//The mysql.js utility function (helper function)
//was created by referencing a precious article at
//https://medium.com/wenchin-rolls-around/example-of-using-transactions-with-async-await-via-mysql-connection-pool-9a37092f226f
const mysql = require('mysql');
let dbConfig = {
    connectionLimit: 100,
    host: 'localhost',
    user: 'request_response_db_adminuser',
    password: 'password123',
    database: 'request_response_db',
    multipleStatements: false
};
const pool = mysql.createPool(dbConfig);
//Create an anonymous function and assign it to the connection
const connection = function() {
    return new Promise(function(resolve, reject) {
        //Create a Promise object so that the calling program can wait for the getConnection method to finish.
        //The getConnection method is given a "call back function" so that the internal logic of the getConnection
        //executes the call back function's logic when an active connection is established with the database.
        pool.getConnection(function(error, connection) {
            if (error) {
                reject(error);
            } // End of if(error)
            console.log('MySQL pool connected: threadId ' + connection.threadId);
            //Create an anonymous function and assign it to the query. Note that, the query "belongs to" 
            //the getConnection's callback function
            const query = function(sql, binding) {
                return new Promise(function(resolve, reject) {
                    connection.query(sql, binding, function(error, results) {
                        if (error) {
                            reject(error);
                        } // End of if(error)
                        resolve(results);
                    }); //End of Promise object "inside" the anonymous function which is given to the query
                }); //End of anonymous function definition for the query
            }; //End of const query = <anonymous function definition>
            //Create an anonymous function and assign it to the release. Note: The release "belongs" to the
            //getConnection's callback function
            const release = function() {
                //The anonymous function's body has a Promise object created, so that the calling program 
                //can wait for the connection.release to finish
                return new Promise(function(resolve, reject) {
                    if (error) {
                        reject(error);
                    } //End of if(error)
                    console.log('MySQL pool released: threadId ' + connection.threadId);
                    resolve(connection.release());
                }); // End of Promise object "inside" the anonymous function which is assigned to the release
            }; // End of the anonymous function's body which is assigned to the release.
            //End of const release = <anonymous function definition>
            resolve({ query, release });
        }); //End of the Promise object definition "inside" the callback function which is 
        //given (provided) to the getConnection
    }); //End of the Promise object definition which is created inside the anonymous function which is
    //assigned to the connection
}; // End of the anonymous function which is given to the connection
const query = function(sql, binding) {
    return new Promise((resolve, reject) => {
        pool.query(sql, binding, function(error, results, fields) {
            if (error) {
                reject(error);
            }
            resolve(results);
        }); // End of "call back function" which is provided to the query method.
    }); // End of Promise object definition which is created inside the anonymous function
}; // End of the anonymous function which is assigned to the query
module.exports = { pool, connection, query };



/*
const connection = () => {
    return new Promise((resolve, reject) => {
        pool.getConnection((err, connection) => {
            if (err) reject(err);
            console.log("MySQL pool connected: threadId " + connection.threadId);
            const query = (sql, binding) => {
                return new Promise((resolve, reject) => {
                    connection.query(sql, binding, (err, result) => {
                        if (err) reject(err);
                        resolve(result);
                    });
                });
            };
            const release = () => {
                return new Promise((resolve, reject) => {
                    if (err) reject(err);
                    console.log("MySQL pool released: threadId " + connection.threadId);
                    resolve(connection.release());
                });
            };
            resolve({ query, release });
        });
    });
};
const query = (sql, binding) => {
    return new Promise((resolve, reject) => {
        pool.query(sql, binding, (err, result, fields) => {
            if (err) reject(err);
            resolve(result);
        });
    });
};
module.exports = { pool, connection, query };

*/