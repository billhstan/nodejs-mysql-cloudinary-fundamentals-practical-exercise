const teamDataManager = require('../services/teamService');

module.exports.createTeamAndTeamMemberData = async function(req, res, next) {
        //console.log(req.headers['content-type']);
        console.log(req.body); //Inspect whether the express-form-data is working
        const data = req.body;
        try {
            const results = await teamDataManager.createTeamAndTeamMemberData(data);
            console.log(results.data.teamId);
            res.status(201).json({
                status: 'success',
                data: null
            });
        } catch (error) {
            console.log(error)
            res.status(500).json({
                status: 'fail',
                data: null
            });

        }

    } // End of async function(req,res,next)