const express = require('express');
const router = express.Router();
const teamController = require('../controllers/teamController');
const os = require("os");
const formData = require('express-form-data');

const options = {
    uploadDir: os.tmpdir(),
    autoClean: true
};
// parse data with connect-multiparty. 
router.use('/teams/detail', formData.parse(options));
// delete from the request all empty files (size == 0)
router.use('/teams/detail', formData.format());
// change the file objects to fs.ReadStream 
router.use('/teams/detail', formData.stream());
// union the body and the files
router.use('/teams/detail', formData.union());

router.post('/teams/detail', teamController.createTeamAndTeamMemberData);

module.exports = router;