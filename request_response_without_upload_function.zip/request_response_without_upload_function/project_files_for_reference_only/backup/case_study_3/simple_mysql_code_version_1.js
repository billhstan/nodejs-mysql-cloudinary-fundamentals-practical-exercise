//This JS file has the necessary code which creates a complete team D and 
//team D data information.
//As long as you have deleted all the TEAM C -TEAM C member data
//As long as you have also deleted all the TEAM D - TEAM D memeber data
//This file is useful to test the asynchronous behavior by observing
//the count variable value printed at the terminal interface.
const mysql = require('mysql');
let dbConfig = {
    connectionLimit: 100,
    host: 'localhost',
    user: 'request_response_db_adminuser',
    password: 'password123',
    database: 'request_response_db',
    multipleStatements: false
};

const pool = mysql.createPool(dbConfig);

pool.getConnection(function(error, connection) {
    if (error) {
        throw error;
    }
    connection.query(`INSERT INTO team(team_name, team_description)
       VALUES ('TEAM D','TEAM D DESCRIPTION')`, function(error, results) {
        console.log('INSERT TEAM D record has completed.');
    });

    connection.query(`SELECT * FROM team`, function(error, results) {
        if (error) {
            throw error;
        }
        console.log('SELECT team records has completed.');
    });


    connection.query(`INSERT INTO team_member(first_name,last_name, member_email,is_leader, team_id)
           VALUES ('BRIZ','QUEENS','briz_queens@email.com',
           false, (SELECT team_id FROM team WHERE team_name='TEAM D') );`,
        function(error, result) {
            if (error) {
                throw error;
            }
            console.log('(INSERT member 1) INSERT team member briz queens for team D has completed.')
        });
    connection.query(`INSERT INTO team_member(first_name,last_name, member_email,is_leader, team_id)
           VALUES ('BRADDY','QUEENS','braddy_queens@email.com',
           false, (SELECT team_id FROM team WHERE team_name='TEAM D') );`,
        function(error, result) {
            if (error) {
                throw error;
            }
            console.log('(INSERT member 2) INSERT team member braddy queens for team D has completed.')
        });
    connection.query(`INSERT INTO team_member(first_name,last_name, member_email,is_leader, team_id)
           VALUES ('BOB','QUEENS','bob_queens@email.com',
           false, (SELECT team_id FROM team WHERE team_name='TEAM D') );`,
        function(error, result) {
            if (error) {
                throw error;
            }
            console.log('(INSERT member 3) INSERT team member bob queens for team D has completed.');
        });


}); // End of pool.getConnection