const cloudinary = require('cloudinary');
cloudinary.config({
    cloud_name: 'dit88888',
    api_key: '142695751934848',
    api_secret: 'meWaJGIeq9oAPtDKT5I5SnWj_cg',
    upload_preset: 'upload_to_team'
});
module.exports.uploadFileToCloudinary = function(file) {
        return new Promise((resolve, reject) => {
            //The following code will upload image to cloudinary
            cloudinary.uploader.upload(file.path, { upload_preset: 'upload_to_team' })
                .then((result) => {
                    //Inspect whether I can obtain the file storage id and the url from cloudinary
                    //after a successful upload.
                    //console.log({imageURL: result.url, publicId: result.public_id});
                    let data = { imageURL: result.url, publicId: result.public_id, status: 'success' };
                    resolve(data);

                }).catch((error) => {

                    let message = 'fail';
                    reject(error);

                }); //End of try..catch
        }); //End of Promise
    } //End of uploadFileToCloudinary