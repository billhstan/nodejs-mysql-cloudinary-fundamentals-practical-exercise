//This JS file causes incomplete team C and team C member record creation
//due to the last record's bob_queens@email.com violating the team_member unique
//constraint rule on the member_email field.
const mysql = require('mysql');
let dbConfig = {
    connectionLimit: 100,
    host: 'localhost',
    user: 'request_response_db_adminuser',
    password: 'password123',
    database: 'request_response_db',
    multipleStatements: false
};

const pool = mysql.createPool(dbConfig);
let count = 1;
pool.getConnection(function(error, connection) {
    if (error) {
        throw error;
    }
    connection.query(`INSERT INTO team(team_name, team_description)
       VALUES ('TEAM C','TEAM C DESCRIPTION')`, function(error, results) {
        console.log('INSERT TEAM C record has completed.');
    });
    connection.query(`SELECT * FROM team`, function(error, results) {
        if (error) {
            throw error;
        }
        console.log('SELECT team records has completed.');
    });
    connection.query(`INSERT INTO team_member(first_name,last_name, member_email,is_leader, team_id)
           VALUES ('FRED','HANS','fred_hans@email.com',
           false, (SELECT team_id FROM team WHERE team_name='TEAM C') );`,
        function(error, result) {
            if (error) {
                throw error;
            }
            console.log('(INSERT member 1) INSERT team member fred hans for team C has completed.');
        });
    connection.query(`INSERT INTO team_member(first_name,last_name, member_email,is_leader, team_id)
           VALUES ('FRANK','HANS','frank_hans@email.com',
           false, (SELECT team_id FROM team WHERE team_name='TEAM C') );`,
        function(error, result) {
            if (error) {
                throw error;
            }
            console.log('(INSERT member 2) INSERT team member frank hans for team C has completed.');
        });
    connection.query(`INSERT INTO team_member(first_name,last_name, member_email,is_leader, team_id)
           VALUES ('BOB','QUEENS','bob_queens@email.com',
           false, (SELECT team_id FROM team WHERE team_name='TEAM C') );`,
        function(error, result) {
            if (error) {
                throw error;
            }
            console.log('(INSERT member 3) INSERT team member bob queens for team C has completed.');
        });


}); // End of pool.getConnection