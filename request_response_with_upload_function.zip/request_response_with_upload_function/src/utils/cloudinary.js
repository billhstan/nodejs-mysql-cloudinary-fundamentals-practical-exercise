const cloudinary = require('cloudinary').v2;
const streamifier = require('streamifier');
cloudinary.config({
    cloud_name: 'dit8jjj8',
    api_key: '384884324343511',
    api_secret: 'p6g156564d888'
});

//uploadStreamToCloudinary - useful if the backend uses the:
// ->direct stream the content to cloudinary without temp file technique
//strategy
module.exports.uploadStreamToCloudinary = function(buffer) {
        return new Promise(function(resolve, reject) {
            //Create a powerful, writable stream object which works with Cloudinary
            let streamDestination = cloudinary.uploader.upload_stream({
                    folder: 'teams',
                    allowed_formats: 'png,jpg',
                    resource_type: 'image'
                },
                function(error, result) {
                    if (result) {
                        //Inspect whether I can obtain the file storage id and the url from cloudinary
                        //after a successful upload.
                        //console.log({imageURL: result.url, publicId: result.public_id});
                        let cloudinaryFileData = { url: result.url, publicId: result.public_id, status: 'success' };
                        resolve({ status: 'success', data: cloudinaryFileData });
                    }
                    if (error) {
                        reject({ status: 'fail', data: error });
                    } // End of if..else block inside the anonymous function given to upload_stream
                });
            streamifier.createReadStream(buffer).pipe(streamDestination);
        }); //End of Promise
    } //End of uploadStreamToCloudinary
     

//uploadFileToCloudinary - useful if the backend uses the:
// ->create temp file first->then use temp file to upload
//strategy
module.exports.uploadFileToCloudinary = function(file) {
        return new Promise((resolve, reject) => {
            //The following code will upload file to cloudinary
            cloudinary.uploader.upload(file.path, { upload_preset: 'upload_to_teams' })
                .then((result) => {
                    //Inspect whether I can obtain the file storage id and the url from cloudinary
                    //after a successful upload.
                    //console.log({imageURL: result.url, publicId: result.public_id});
                    let data = { url: result.url, publicId: result.public_id, status: 'success' };
                    resolve({ status: 'success', data: data });

                }).catch((error) => {
                    reject({ status: 'fail', data: error });
                }); //End of try..catch
        }); //End of Promise
    } //End of uploadFileToCloudinary