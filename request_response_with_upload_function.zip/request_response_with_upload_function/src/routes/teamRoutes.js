const express = require('express');
const router = express.Router();
const teamController = require('../controllers/teamController');
const multer = require('multer')


const upload = multer({ storage: multer.memoryStorage() }).array('file', 2);


router.post('/teams/detail', upload, teamController.createTeamAndTeamMemberData);
module.exports = router;