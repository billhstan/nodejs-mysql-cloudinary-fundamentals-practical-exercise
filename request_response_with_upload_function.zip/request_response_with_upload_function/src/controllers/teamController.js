const teamDataManager = require('../services/teamService');

module.exports.createTeamAndTeamMemberData = async function(req, res, next) {
        //console.log(req.body);
        console.log(req.files);
        try {
            const results = await teamDataManager.createTeamAndTeamMemberData(req);
            //console.log(results.data.teamId);
            res.status(201).json({
                status: 'success',
                data: null
            });
        } catch (error) {
            console.log(error)
            res.status(500).json({
                status: 'fail',
                data: null
            });

        }
    } // End of async function(req,res,next)




















    

module.exports.getFile = async function(req, res, next) {
        fetch('https://res.cloudinary.com/dit88888/raw/upload/v1626267297/teams/test.docx')
            .then(
                x =>
                new Promise((resolve, reject) => {
                    x.body.pipe(res);
                    x.body.on("end", () => resolve("it worked"));
                    res.on("error", reject);
                })
            )
            .then(x => console.log(x));
} // End of async function(req,res,next)