const mysql = require('../utils/mysql');
const cloudinary = require('../utils/cloudinary');

module.exports.createTeamAndTeamMemberData = async function(req) {
        //Usually database operation functions do not take in the whole request object
        //as an input. For this createTeamAndTeamMemberData function, we don't have a choice
        //because the multer library internal logic creates body property to hold the text data
        //key-value pair portion and creates files property to hold the file data portion.
        let data = req.body;

        return new Promise(async function(resolve, reject) {
            const connection = await mysql.connection();
            try {
                await connection.query('START TRANSACTION');
                const createTeamResults = await connection.query(`INSERT INTO team (team_name,team_description)
        VALUES (? , ?)`, [data.teamName, data.teamDescription]);
                console.log(createTeamResults.insertId);
                await connection.query(`INSERT INTO team_member 
        (first_name,last_name,member_email,is_leader,team_id) 
        VALUES (?,?,?,?,?)`, [data.firstName[0], data.lastName[0], data.email[0],
                    (data.isLeader[0] == 'true') ? 1 : 0, createTeamResults.insertId
                ]);
                await connection.query(`INSERT INTO team_member 
        (first_name,last_name,member_email,is_leader,team_id) 
        VALUES (?,?,?,?,?)`, [data.firstName[1], data.lastName[1], data.email[1],
                    (data.isLeader[1] == 'true') ? 1 : 0, createTeamResults.insertId
                ]);
                await connection.query(`INSERT INTO team_member 
        (first_name,last_name,member_email,is_leader,team_id) 
        VALUES (?,?,?,?,?)`, [data.firstName[2], data.lastName[2], data.email[2],
                    (data.isLeader[2] == 'true') ? 1 : 0, createTeamResults.insertId
                ]);
                let fileUploadResult = null;
                for (let fileIndex = 0; fileIndex < req.files.length; fileIndex++) {
                    //console.log(req.files[fileIndex]);
                    //upload file first
                    fileUploadResult = await cloudinary.uploadStreamToCloudinary(req.files[fileIndex].buffer);
                    //fileUploadResult = await cloudinary_v2.uploadStreamToCloudinary(req.files[fileIndex].buffer);
                    //create record in team_file table
                    await connection.query(`INSERT INTO team_file (cloudinary_file_id,cloudinary_url,original_filename, mime_type,
      team_id) VALUES (?,?,?,?,?)`, [fileUploadResult.data.publicId, fileUploadResult.data.url,
                        req.files[fileIndex].originalname, req.files[fileIndex].mimetype, createTeamResults.insertId
                    ]);
                } //End of for loop logic to stream 2 files to cloudinary file respository
                await connection.query('COMMIT');
                resolve({ status: 'success', data: { teamId: createTeamResults.insertId } });
            } catch (error) {
                if (error) {
                    console.log(error);
                    await connection.query('ROLLBACK');
                    reject({ status: 'fail', data: error });
                }
            } finally {
                await connection.release();

            } // End of try-catch-finally block
        }); // End of Promise object definition
    } // End of createTeamAndTeamMemberData function
    // (to be exported out for calling program to use)