const cloudinary = require('../src/utils/cloudinary');
const mysql = require('../src/utils/mysql');
const fs = require('fs');

async function createTeamARecordsAndFileData() {
    return new Promise(async function(resolve, reject) {
        let buffer = null;
        const data = {
            teamName: 'TEAM A',
            teamDescription: `TEAM A description`,
            firstName: ['FILLIS', 'FAZA', 'FIN'],
            lastName: ['SANDS', 'SANDS', 'SANDS'],
            email: [
                'fillis_sands@email.com',
                'faza_sands@email.com',
                'fin_sands@email.com'
            ],
            isLeader: ['true', 'false', 'false'],
            files: [{ originalname: 'team_a_logo.png', mimetype: 'image/png', path: './team_a/team_a_logo.png' },
                { originalname: 'team_a_logo.png', mimetype: 'image/png', path: './team_a/team_a_group_photo.png' }
            ]
        }
        const connection = await mysql.connection();
        try {
            await connection.query('START TRANSACTION');
            const createTeamResults = await connection.query(`INSERT INTO team (team_name,team_description)
    VALUES (? , ?)`, [data.teamName, data.teamDescription]);
            console.log(createTeamResults.insertId);
            await connection.query(`INSERT INTO team_member 
    (first_name,last_name,member_email,is_leader,team_id) 
    VALUES (?,?,?,?,?)`, [data.firstName[0], data.lastName[0], data.email[0],
                (data.isLeader[0] == 'true') ? 1 : 0, createTeamResults.insertId
            ]);
            await connection.query(`INSERT INTO team_member 
    (first_name,last_name,member_email,is_leader,team_id) 
    VALUES (?,?,?,?,?)`, [data.firstName[1], data.lastName[1], data.email[1],
                (data.isLeader[1] == 'true') ? 1 : 0, createTeamResults.insertId
            ]);
            await connection.query(`INSERT INTO team_member 
    (first_name,last_name,member_email,is_leader,team_id) 
    VALUES (?,?,?,?,?)`, [data.firstName[2], data.lastName[2], data.email[2],
                (data.isLeader[2] == 'true') ? 1 : 0, createTeamResults.insertId
            ]);
            let fileUploadResult = null;
            for (let fileIndex = 0; fileIndex < data.files.length; fileIndex++) {
                buffer = fs.readFileSync(data.files[fileIndex].path);
                //upload file first
                fileUploadResult = await cloudinary.uploadStreamToCloudinary(buffer);
                //create record in team_file table
                await connection.query(`INSERT INTO team_file (cloudinary_file_id,cloudinary_url,original_filename, mime_type,
  team_id) VALUES (?,?,?,?,?)`, [fileUploadResult.data.publicId, fileUploadResult.data.url,
                    data.files[fileIndex].originalname, data.files[fileIndex].mimetype, createTeamResults.insertId
                ]);
            } //End of for loop logic to stream 2 files to cloudinary file respository
            await connection.query('COMMIT');
            resolve({ status: 'success', data: { teamId: createTeamResults.insertId } });
        } catch (error) {
            if (error) {
                console.log(error);
                await connection.query('ROLLBACK');
                reject({ status: 'fail', data: error });
            }
        } finally {
            await connection.release();

        } // End of try-catch-finally block
    }); // End of Promise object definition
}

async function createTeamBRecordsAndFileData() {
    return new Promise(async function(resolve, reject) {
        const data = {
            teamName: 'TEAM B',
            teamDescription: `TEAM B description`,
            firstName: ['TINY', 'TAZ', 'TORO'],
            lastName: ['BAZE', 'BAZE', 'BAZE'],
            email: [
                'tiny_baze@email.com',
                'taz_baze@email.com',
                'toro_baze@email.com'
            ],
            isLeader: ['true', 'false', 'false'],
            files: [{ originalname: 'team_b_logo.png', mimetype: 'image/png', path: './team_b/team_b_logo.png' },
                { originalname: 'team_b_logo.png', mimetype: 'image/png', path: './team_b/team_b_group_photo.png' }
            ]
        }
        const connection = await mysql.connection();
        try {
            await connection.query('START TRANSACTION');
            const createTeamResults = await connection.query(`INSERT INTO team (team_name,team_description)
    VALUES (? , ?)`, [data.teamName, data.teamDescription]);
            console.log(createTeamResults.insertId);
            await connection.query(`INSERT INTO team_member 
    (first_name,last_name,member_email,is_leader,team_id) 
    VALUES (?,?,?,?,?)`, [data.firstName[0], data.lastName[0], data.email[0],
                (data.isLeader[0] == 'true') ? 1 : 0, createTeamResults.insertId
            ]);
            await connection.query(`INSERT INTO team_member 
    (first_name,last_name,member_email,is_leader,team_id) 
    VALUES (?,?,?,?,?)`, [data.firstName[1], data.lastName[1], data.email[1],
                (data.isLeader[1] == 'true') ? 1 : 0, createTeamResults.insertId
            ]);
            await connection.query(`INSERT INTO team_member 
    (first_name,last_name,member_email,is_leader,team_id) 
    VALUES (?,?,?,?,?)`, [data.firstName[2], data.lastName[2], data.email[2],
                (data.isLeader[2] == 'true') ? 1 : 0, createTeamResults.insertId
            ]);
            let fileUploadResult = null;
            for (let fileIndex = 0; fileIndex < data.files.length; fileIndex++) {
                buffer = fs.readFileSync(data.files[fileIndex].path);
                //upload file first
                fileUploadResult = await cloudinary.uploadStreamToCloudinary(buffer);
                //create record in team_file table
                await connection.query(`INSERT INTO team_file (cloudinary_file_id,cloudinary_url,original_filename, mime_type,
  team_id) VALUES (?,?,?,?,?)`, [fileUploadResult.data.publicId, fileUploadResult.data.url,
                    data.files[fileIndex].originalname, data.files[fileIndex].mimetype, createTeamResults.insertId
                ]);
            } //End of for loop logic to stream 2 files to cloudinary file respository
            await connection.query('COMMIT');
            resolve({ status: 'success', data: { teamId: createTeamResults.insertId } });
        } catch (error) {
            if (error) {
                console.log(error);
                await connection.query('ROLLBACK');
                reject({ status: 'fail', data: error });
            }
        } finally {
            await connection.release();

        } // End of try-catch-finally block
    }); // End of Promise object definition
}

async function createTeamSyntaxErrorRecordsAndFileData() {
    return new Promise(async function(resolve, reject) {
        const data = {
            teamName: 'SYNTAX ERROR',
            teamDescription: `Code to serve`,
            firstName: ['ADRIZ', 'AGASI', 'ABLE'],
            lastName: ['COLE', 'COLE', 'COLE'],
            email: [
                'adriz_cole@email.com',
                'agasi_cole@email.com',
                'able_cole@email.com'
            ],
            isLeader: ['true', 'false', 'false'],
            files: [{ originalname: 'syntax_error_logo.png', mimetype: 'image/png', path: './syntax_error/syntax_error_logo.png' },
                { originalname: 'syntax_error_team_photo.png', mimetype: 'image/png', path: './syntax_error/syntax_error_team_photo.png' }
            ]
        }
        const connection = await mysql.connection();
        try {
            await connection.query('START TRANSACTION');
            const createTeamResults = await connection.query(`INSERT INTO team (team_name,team_description)
    VALUES (? , ?)`, [data.teamName, data.teamDescription]);
            console.log(createTeamResults.insertId);
            await connection.query(`INSERT INTO team_member 
    (first_name,last_name,member_email,is_leader,team_id) 
    VALUES (?,?,?,?,?)`, [data.firstName[0], data.lastName[0], data.email[0],
                (data.isLeader[0] == 'true') ? 1 : 0, createTeamResults.insertId
            ]);
            await connection.query(`INSERT INTO team_member 
    (first_name,last_name,member_email,is_leader,team_id) 
    VALUES (?,?,?,?,?)`, [data.firstName[1], data.lastName[1], data.email[1],
                (data.isLeader[1] == 'true') ? 1 : 0, createTeamResults.insertId
            ]);
            await connection.query(`INSERT INTO team_member 
    (first_name,last_name,member_email,is_leader,team_id) 
    VALUES (?,?,?,?,?)`, [data.firstName[2], data.lastName[2], data.email[2],
                (data.isLeader[2] == 'true') ? 1 : 0, createTeamResults.insertId
            ]);
            let fileUploadResult = null;
            for (let fileIndex = 0; fileIndex < data.files.length; fileIndex++) {
                buffer = fs.readFileSync(data.files[fileIndex].path);
                //upload file first
                fileUploadResult = await cloudinary.uploadStreamToCloudinary(buffer);
                //create record in team_file table
                await connection.query(`INSERT INTO team_file (cloudinary_file_id,cloudinary_url,original_filename, mime_type,
  team_id) VALUES (?,?,?,?,?)`, [fileUploadResult.data.publicId, fileUploadResult.data.url,
                    data.files[fileIndex].originalname, data.files[fileIndex].mimetype, createTeamResults.insertId
                ]);
            } //End of for loop logic to stream 2 files to cloudinary file respository
            await connection.query('COMMIT');
            resolve({ status: 'success', data: { teamId: createTeamResults.insertId } });
        } catch (error) {
            if (error) {
                console.log(error);
                await connection.query('ROLLBACK');
                reject({ status: 'fail', data: error });
            }
        } finally {
            await connection.release();

        } // End of try-catch-finally block
    }); // End of Promise object definition
}


//Start a IIFE block so that can use the async keyword
(async function prepareTestRecordsAndFileData() {
    try {
        await createTeamARecordsAndFileData();
        await createTeamBRecordsAndFileData();
        await createTeamSyntaxErrorRecordsAndFileData();
    } catch (error) {
        console.log(error);
    } finally {
        console.log('Data seeding has completed');
        process.exit();

    }

})()