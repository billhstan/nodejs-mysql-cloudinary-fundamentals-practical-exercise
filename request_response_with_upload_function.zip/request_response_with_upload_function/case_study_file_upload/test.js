const cloudinary = require('./experiment_cloudinary');
const fs = require('fs');




(async function() {
    const buffer = fs.readFileSync('yellow_box.bmp');


    try {
        const fileUploadResult = await cloudinary.uploadStreamToCloudinary(buffer);
        console.log(fileUploadResult);
    } catch (error) {
        console.log(error);
    }
})()