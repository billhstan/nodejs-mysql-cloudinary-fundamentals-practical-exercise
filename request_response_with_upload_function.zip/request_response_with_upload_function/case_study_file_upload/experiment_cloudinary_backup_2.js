const cloudinary = require('cloudinary').v2;
const streamifier = require('streamifier');
const fs = require('fs');
cloudinary.config({
    cloud_name: 'dit88sdfsdfs888',
    api_key: '3848973sfdsf43783sdf777',
    api_secret: 'p6NEsdfsdfbofdJddddddkdrf5g14dsdfsdfZO7TD4Y4Q',
    secure: true
});
let buffer = fs.readFileSync('yellow_box.bmp');
console.log(buffer);
const destinationStream = cloudinary.uploader.upload_stream({
    allowed_formats: 'jpg,png',
    resource_type: 'image',
    folder: 'teams',
}, function(error, result) {
    if (error != null) {
        //If the error parameter variable
        //has values, print the error to terminal
        console.log(error);
        return;
    }
    if (result != null) {
        //If the result parameter variable
        //has values, print the result to terminal        
        console.log(result);
    }
})

streamifier.createReadStream(buffer).pipe(destinationStream);

/*
//Experiment 1
const streamDestination = fs.createWriteStream('a.png');
const streamDataSource = fs.createReadStream('team_d_logo.png');
streamDataSource.pipe(streamDestination);
//Experiment 2
const streamDestination2 = fs.createWriteStream('b.png');
const streamDataSource2 = streamifier.createReadStream(buffer);
streamDataSource2.pipe(streamDestination2);


*/