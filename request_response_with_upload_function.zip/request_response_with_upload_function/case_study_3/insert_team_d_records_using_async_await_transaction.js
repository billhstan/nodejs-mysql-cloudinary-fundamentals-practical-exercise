const mysql = require('./utils/mysql');
const data = {
    teamName: 'TEAM D',
    teamDescription: `TEAM D Description`,
    firstName: ['BRIZ', 'BRADDY', 'BOB'],
    lastName: ['QUEENS', 'QUEENS', 'QUEENS'],
    email: [
        'briz_queens@email.com',
        'braddy_queens@email.com',
        'bob_queens@email.com'
    ],
    isLeader: ['true', 'false', 'false']
};

async function createTeamAndTeamMemberData(data) {
    const connection = await mysql.connection();
    try {
        await connection.query('START TRANSACTION');
        const createTeamResults = await connection.query(`INSERT INTO team (team_name,team_description)
        VALUES (? , ?)`, [data.teamName, data.teamDescription]);
        await connection.query(`INSERT INTO team_member 
        (first_name,last_name,member_email,is_leader,team_id) 
        VALUES (?,?,?,?,?)`, [data.firstName[0], data.lastName[0], data.email[0],
            (data.isLeader[0] == 'true') ? 1 : 0, createTeamResults.insertId
        ]);
        await connection.query(`INSERT INTO team_member 
        (first_name,last_name,member_email,is_leader,team_id) 
        VALUES (?,?,?,?,?)`, [data.firstName[1], data.lastName[1], data.email[1],
            (data.isLeader[1] == 'true') ? 1 : 0, createTeamResults.insertId
        ]);
        await connection.query(`INSERT INTO team_member 
        (first_name,last_name,member_email,is_leader,team_id) 
        VALUES (?,?,?,?,?)`, [data.firstName[2], data.lastName[2], data.email[2],
            (data.isLeader[2] == 'true') ? 1 : 0, createTeamResults.insertId
        ]);

        await connection.query('COMMIT');

    } catch (error) {
        if (error) {
            console.log(error);
            await connection.query('ROLLBACK');
        }
    } finally {
        await connection.release();

    } // End of try-catch-finally block
} // End of createTeamAndTeamMemberData

createTeamAndTeamMemberData(data);