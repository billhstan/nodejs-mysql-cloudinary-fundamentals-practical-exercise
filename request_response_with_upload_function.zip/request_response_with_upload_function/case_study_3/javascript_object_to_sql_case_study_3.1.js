//Topic: Experiment JavaScript data object and how it can be used to create records inside the database.
//Assume that the, your NodeJS backend project
//is able to build a data object below which
//describes team and team member data.
//Construct the necessary SQL commands which are applicable
//for creating the team-team member parent-child records.
const data = {
    teamName: 'SOFT ZOMBIE',
    teamDescription: `We develop softwares for people to edit cartoons. 
    We aim to develop artificial intelligent tools to help users 
    bring their imagination into the digital world in minutes.`,
    firstName: ['AMANDA', 'AMY', 'ALICE'],
    lastName: ['KING', 'KING', 'KING'],
    email: [
        'amanda_king@email.com',
        'amy_king@email.com',
        'alice_king@email.com'
    ],
    isLeader: ['true', 'false', 'false']
}
console.log(buildCreateTeamAndTeamMemberSQL(data));

function buildCreateTeamAndTeamMemberSQL(data) {
    let sql = '';
    sql = sql + `INSERT INTO team(team_name, team_description)
      VALUES ('${data.teamName}','${data.teamDescription}' );\n`;
    for (let index = 0; index < 3; index++) {
        sql = sql +
            `INSERT INTO team_member(first_name,last_name, member_email,is_leader, team_id)
          VALUES ('${data.firstName[index]}','${data.lastName[index]}','${data.email[index]}',
          ${data.isLeader[index]}, 
          (SELECT team_id FROM team WHERE team_name='${data.teamName}') );\n`;
    }
    return sql;
}