//------------------------------------------------------------------------------------
// Topic:
//------------------------------------------------------------------------------------
//Experiment two major problems.
//Problem 2: [Asynchronous JavaScript behavior]
//The following code creates complete Team D and Team D member data.
//You have to keep deleting Team D and Team D member records before
//you retest the JS file.
//The code focuses on watching the count variable value changes to
//feel the asynchronous behavior
//------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------
const mysql = require('mysql');
let dbConfig = {
    connectionLimit: 100,
    host: 'localhost',
    user: 'request_response_db_adminuser',
    password: 'password123',
    database: 'request_response_db',
    multipleStatements: false
};
const pool = mysql.createPool(dbConfig);
let count = 0;
pool.getConnection(function(error, connection) {
    if (error) {
        throw error;
    }
    connection.query(`INSERT INTO team(team_name, team_description)
       VALUES ('TEAM D','TEAM D DESCRIPTION')`, function(error, results) {
        count = count + 1; //JavaScript engine already executed the line : 70
        console.log('INSERT TEAM D record has completed.');
    });
    connection.query(`SELECT * FROM team`, function(error, results) {
        if (error) {
            throw error;
        }
        count = count + 1; //JavaScript engine already executed the line : 70
        console.log('SELECT team records has completed.');
    });
    connection.query(`INSERT INTO team_member(first_name,last_name, member_email,is_leader, team_id)
           VALUES ('BRIZ','QUEENS','briz_queens@email.com',
           false, (SELECT team_id FROM team WHERE team_name='TEAM D') );`,
        function(error, result) {
            if (error) {
                throw error;
            }
            count = count + 1; //JavaScript engine already executed the line : 70
            console.log('(INSERT member 1) INSERT team member fred hans for team D has completed.');
        });
    connection.query(`INSERT INTO team_member(first_name,last_name, member_email,is_leader, team_id)
        VALUES ('BRADDY','QUEENS','braddy_queens@email.com',
        false, (SELECT team_id FROM team WHERE team_name='TEAM D') );`,
        function(error, result) {
            if (error) {
                throw error;
            }
            count = count + 1; //JavaScript engine already executed the line :70
            console.log('(INSERT member 2) INSERT team member frank hans for team D has completed.');
        });
    connection.query(`INSERT INTO team_member(first_name,last_name, member_email,is_leader, team_id)
        VALUES ('BOB','QUEENS','bob_queens@email.com',
        false, (SELECT team_id FROM team WHERE team_name='TEAM D') );`,
        function(error, result) {
            if (error) {
                throw error;
            }
            count = count + 1; //JavaScript engine already executed the line : 70
            console.log('(INSERT member 3) INSERT team member bob queens for team D has completed.');
        });
    console.log(count); //JavaScript engine executes this "far too early"

}); // End of pool.getConnection