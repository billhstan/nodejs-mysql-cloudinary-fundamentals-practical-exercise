-- file name: create_db_tables_with_team_file_table.sql
DROP DATABASE IF EXISTS request_response_db;
Create Database request_response_db CHARACTER SET latin1 COLLATE latin1_general_ci;
Use request_response_db;
 CREATE TABLE team(
     team_id int NOT NULL AUTO_INCREMENT,
     team_name varchar(500) NOT NULL,
     team_description varchar(500) NOT NULL,
     PRIMARY KEY (team_id),
     UNIQUE(team_name)
)AUTO_INCREMENT=1;   

CREATE TABLE team_member(
     team_member_id int NOT NULL AUTO_INCREMENT,
     first_name varchar(100) NOT NULL,
     last_name varchar(100) NOT NULL,
     member_email varchar(200) NOT NULL,
     is_leader boolean NOT NULL,
     team_id int NOT NULL,
     PRIMARY KEY (team_member_id),
     UNIQUE(member_email),
	 FOREIGN KEY (team_id) REFERENCES team(team_id) 
)AUTO_INCREMENT=1;   

 CREATE TABLE team_file (
  team_file_id int NOT NULL AUTO_INCREMENT,
  cloudinary_file_id varchar(255) COLLATE latin1_general_ci NOT NULL,
  cloudinary_url varchar(255) COLLATE latin1_general_ci NOT NULL,
  original_filename varchar(255) COLLATE latin1_general_ci NOT NULL,
  mime_type varchar(100) COLLATE latin1_general_ci NOT NULL,
  team_id int NOT NULL,
  FOREIGN KEY (team_id) REFERENCES team(team_id) ,
  PRIMARY KEY (team_file_id)
);

DROP USER IF EXISTS 'request_response_db_adminuser'@'localhost';
CREATE USER 'request_response_db_adminuser'@'localhost' IDENTIFIED BY 'password123';
GRANT ALL PRIVILEGES ON request_response_db.* TO 'request_response_db_adminuser'@'localhost';
ALTER USER 'request_response_db_adminuser'@'localhost' IDENTIFIED WITH mysql_native_password BY 'password123';
FLUSH PRIVILEGES;

