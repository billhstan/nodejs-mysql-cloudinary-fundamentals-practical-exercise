const cloudinary = require('cloudinary').v2;
const streamifier = require('streamifier');
cloudinary.config({
    cloud_name: 'dit88888',
    api_key: '384897343783511',
    api_secret: 'p6NEbofdJkdrf5g14dZO7TD4Y4Q'
});

//uploadStreamToCloudinary - useful if the backend uses the:
// ->direct stream the content to cloudinary without temp file technique
//strategy
module.exports.uploadStreamToCloudinary = function(buffer) {
        return new Promise(function(resolve, reject) {
            //Create a function, uploadStream which
            //knows to which Cloudinary account repository it should send the 
            //digital file content data to.
            const uploadStream = cloudinary.uploader.upload_stream({
                    allowed_formats: 'jpg,jpeg,png',
                    upload_preset: 'upload_to_teams'
                },
                function(error, result) {
                    console.log('---------------------------------------------------------------');
                    console.log('The anonymous function given to cloudinary.uploader.upload_stream has executed');
                    if (result) {
                        //Inspect whether I can obtain the file storage id and the url from cloudinary
                        //after a successful upload.
                        //console.log({imageURL: result.url, publicId: result.public_id});
                        let cloudinaryFileData = { url: result.url, publicId: result.public_id, status: 'success' };
                        resolve({ status: 'success', data: cloudinaryFileData });
                    }
                    if (error) {
                        reject({ status: 'fail', data: error });
                    } // End of if..else block inside the anonymous function given to upload_stream
                });
            console.log('Check the buffer variable\'s content');
            console.log('---------------------------------------------------------------');
            console.log(buffer);
            readableStream = streamifier.createReadStream(buffer).pipe(uploadStream);

        }); //End of Promise
    } //End of uploadStreamToCloudinary
    //uploadFileToCloudinary - useful if the backend uses the:
    // ->create temp file->use temp file to upload
    //strategy
module.exports.uploadFileToCloudinary = function(file) {
        return new Promise((resolve, reject) => {
            //The following code will upload file to cloudinary
            cloudinary.uploader.upload(file.path, { upload_preset: 'upload_to_teams' })
                .then((result) => {
                    //Inspect whether I can obtain the file storage id and the url from cloudinary
                    //after a successful upload.
                    //console.log({imageURL: result.url, publicId: result.public_id});
                    let data = { url: result.url, publicId: result.public_id, status: 'success' };
                    resolve({ status: 'success', data: data });

                }).catch((error) => {
                    reject({ status: 'fail', data: error });
                }); //End of try..catch
        }); //End of Promise
    } //End of uploadFileToCloudinary