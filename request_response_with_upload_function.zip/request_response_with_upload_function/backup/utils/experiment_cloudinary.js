const cloudinary = require('cloudinary').v2;
const streamifier = require('streamifier');
//const fs = require('fs');
cloudinary.config({
    cloud_name: 'dit88888',
    api_key: '384897343783511',
    api_secret: 'p6NEbofdJkdrf5g14dZO7TD4Y4Q',
    secure: true
});

//const buffer = fs.readFileSync('yellow_box.bmp');

module.exports.uploadStreamToCloudinary = function(buffer) {
    return new Promise(
        function(resolve, reject) {
            let streamDestination = cloudinary.uploader.upload_stream({ folder: 'teams', allowed_formats: 'png,jpg', resource_type: 'image' },
                function(error, result) {
                    if (result != null) {
                        console.log(result);
                        const cloudinaryFileData = { publicId: result.public_id, url: result.url };
                        resolve({ status: 'success', data: cloudinaryFileData });
                    } else {
                        console.log(error);
                        reject({ status: 'fail', data: error });
                    }
                });

            streamifier.createReadStream(buffer).pipe(streamDestination);
        }
    )
}















/*console.log(buffer instanceof Buffer); // true

console.log(buffer); // '<Buffer 7b 0a 20 20 22 6e 61 6d 65 22 ...>'
//Experiment 1
const streamDestination = fs.createWriteStream('a.png');
const streamDataSource = fs.createReadStream('team_d_logo.png');
streamDataSource.pipe(streamDestination);
//Experiment 2
const streamDestination2 = fs.createWriteStream('b.png');
const streamDataSource2 = streamifier.createReadStream(buffer);
streamDataSource2.pipe(streamDestination2);*/