const mysql = require('./utils/mysql');

//Execute the following function to begin team-team member data creation
createTeamAndTeamMembersData();

async function createTeamAndTeamMembersData() {

    let count = 1;
    const connection = await mysql.connection();
    try {

        //Send START TRANSACTION SQL command to database engine
        //so that it begins executing the subsequent SQL
        //but will not commit the changes yet.
        await connection.query('START TRANSACTION');
        //Send the SQL command to create TEAM D record
        const createTeamResults =
            await connection.query(`INSERT INTO team(team_name, team_description)
        VALUES ('TEAM C','TEAM C DESCRIPTION')`, []);
        count = count + 1;
        console.log('INSERT TEAM C record has completed.');


        const createTeamMember1Results = await connection.query(`INSERT INTO team_member(first_name,last_name, member_email,is_leader, team_id)
        VALUES ('FRED','HANS','frank_hans@email.com',
           false, (SELECT team_id FROM team WHERE team_name='TEAM C') );`);
        count = count + 1;
        console.log('(INSERT member 1) INSERT team member fred hans for team C has completed.')

        const createTeamMember2Results = await connection.query(`INSERT INTO team_member(first_name,last_name, member_email,is_leader, team_id)
        VALUES ('FRANK','HANS','frank_hans@email.com',
           false, (SELECT team_id FROM team WHERE team_name='TEAM C') );`);
        count = count + 1;
        console.log('(INSERT member 2) INSERT team member frank hans for team C has completed.')

        const createTeamMember3Results = await connection.query(`INSERT INTO team_member(first_name,last_name, member_email,is_leader, team_id)
           VALUES ('BOB','QUEENS','bob_queens@email.com',
           false, (SELECT team_id FROM team WHERE team_name='TEAM C') );`);
        count = count + 1;
        console.log('(INSERT member 3) INSERT team member bob queens for team C has completed.');

        await connection.query('COMMIT');
        //If the JavaScript engine reaches the command below,
        //the record creation process should be successful.
        //Because any database error will lead the JavaScript
        //engine jump straight to the catch block area.
        console.log(count);


    } catch (error) {
        console.log('Failed to create a complete set of team-team member data');
        console.log('Inspect the error object:\n')
        console.log(error);
        await connection.query('ROLLBACK');
    } finally {
        await connection.release();
    } // End of try-catch-finally block

} //End of createTeamAndTeamMembersData