const mysql = require('../../case_study_3/utils/mysql');
//Testing the mysql.query written by the author
async function createOneTeamRecord() {
    let teamName = 'TEAM A';
    let teamDescription = 'TEAM DESCRIPTION'
    try {
        const results = await mysql.query(`INSERT INTO TEAM (team_name,team_description)
        VALUES (?,?)  `, [teamName, teamDescription]);
        console.log(`The new team id for the new record is ${results.insertId}`);

    } catch (error) {
        if (error) {
            console.log('create team data operation has failed');
            console.log(error);
        } // End of the if block to check on error object
    } // end of try..catch block

} // End of async function, createOneTeamRecord

createOneTeamRecord();

//Remember to CTRL+C to terminate the program after node testing_mysql_utility_query_method.js